import pymongo

db_client = pymongo.MongoClient("mongodb://localhost:27017/")

current_db = db_client["DNS"]

collection = current_db["client"]

# new_product = {
#   "Model": "telephone",
#   "Name": "smartphone",
#   "Price": 228000,
#   "manufacturer": "samara technonlogy",
#   "category": "smartphone",
#   "Product ID": 14
# }
#
# ins_result = collection.insert_one(new_product)
# print(ins_result.inserted_id)
#
# for product in collection.find():
#   print(product)
#
# print(collection.count_documents({"Price": {"$gt": 100000}}))
#
# print(collection.count_documents({"Price": {"$lt": 10000}}))
#
# for product in collection.find({'Price': {'$gt': 50000}}).sort('Name'):
#     print(product['Name'], ' ', product['Model'], ' ', product['Price'])
#
# for product in collection.find({'Price': {'$lt': 20000}}).sort('Name'):
#     print(product['Name'], ' ', product['Model'])
#
# query = {'Price': {'$in': list(range(30000, 60000))}}
# for product in collection.find(query):
#     print(product['Name'], ' ', product['Model'], ' ', product['Price'], ' ', product['manufacturer'])

print(collection.count_documents({"Client id": {"$gt": 0}}))